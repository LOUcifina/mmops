mmpOS agent for windows
--------------------------

Please report all problems you encounter. 

Register your rig:
* Use rig code entry within the console window 
* Use dashboard auto register with rig ip (if firewall is enabled ensure you allow 8080 incoming)

Additional notes:

* Please install latest AMD drivers
* Agent will enable "compute mode" on all AMD cards on the system. It also disables crossfire autodetection. 
  If changes needs to be applied a short disable/enable of the AMD cards will be triggered to apply changes without reboot.
  This should happen only once.
* Use agent.exe --help for help
* If you want to start agent automatically on login, use agent.exe --autostart (or use setup-autorun.bat).
  You can disable/remove the autostart by calling the agent.exe --autostart again.
* All miners will be downloaded to a "miners" subdirectory, so should be easy to exclude from virus scanners